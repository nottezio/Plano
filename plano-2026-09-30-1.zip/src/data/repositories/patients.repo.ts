import {
  arrayUnion,
  deleteDoc,
  deleteField,
  FieldPath,
  getDocFromCache,
  getDocs,
  writeBatch,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type DocumentData,
  type DocumentReference,
  type QuerySnapshot,
  type Unsubscribe,
} from 'firebase/firestore';
import { nanoid } from 'nanoid';

import { getDeviceId } from '../deviceId';
import { clinicalStart } from '@/domain/identity';
import { kjsRole } from '@/domain/board';
import { primaryDpjp } from '@/domain/dpjp';
import { isIgdEntry } from '@/domain/clinicalDate';
import { parsePatientFacts } from '@/domain/parsePatient';
import { konsulPreview } from '@/domain/konsulReply';
import { parseSections } from '@/domain/sections/parseSections';
import { DEFAULT_SECTION_ALIASES } from '@/domain/sections/aliases';
import type { SectionAlias } from '@/domain/types';
import type { ReminderSetting } from '@/domain/reminders';
import {
  checklistCol,
  entriesCol,
  patientDoc,
  patientsCol,
  revisionsCol,
} from '../paths';
import { db } from '../firebase';
import { trackWrite } from '../syncStatus';
import type {
  ArchiveReason,
  ClinicalDate,
  Patient,
  PatientStatus,
  Sex,
} from '@/domain/types';

/**
 * SPEC 5 — "UI never imports firebase/firestore directly."
 * Everything crosses this boundary.
 */

export interface CreatePatientInput {
  /**
   * Optional. A patient created from the board's + button has no name yet —
   * the board titles them from the first line of their note until someone
   * fills this in. Requiring it here would put a form between the user and a
   * blank page, which is the one thing this app must never do (SPEC 1.2).
   */
  name?: string;
  admittedAt: ClinicalDate;
  mrn?: string;
  age?: number;
  sex?: Sex;
  ward?: string;
  room?: string;
  bed?: string;
  dpjp?: string;
  diagnoses?: string[];
  labels?: string[];
  /** Lands in the Titipan list rather than the main one. */
  temporary?: boolean;
}

/** F10 — lowercase haystack for instant offline search. */
export function buildSearchBlob(
  patient: Pick<Patient, 'name' | 'diagnoses'> &
    Partial<Pick<Patient, 'mrn' | 'bed' | 'ward' | 'dpjp'>>,
): string {
  return [patient.name, patient.mrn, patient.bed, patient.ward, patient.dpjp, ...patient.diagnoses]
    .filter((part): part is string => Boolean(part))
    .join(' ')
    .toLowerCase();
}

/**
 * Client-generated nanoid (SPEC 6.3): the document id exists before the write
 * leaves the device, so creating a patient in airplane mode is instant, has a
 * stable route, and cannot produce a duplicate on reconnect.
 */
export function createPatient(uid: string, input: CreatePatientInput): {
  id: string;
  written: Promise<void>;
} {
  const id = nanoid(12);
  const diagnoses = input.diagnoses ?? [];
  const labels = input.labels ?? [];

  const record: DocumentData = {
    id,
    ownerId: uid,
    memberIds: [uid],
    name: input.name?.trim() ?? '',
    notes: '',
    diagnoses,
    labels,
    admittedAt: input.admittedAt,
    status: 'active' satisfies PatientStatus,
    pinned: false,
    colorOverride: null,
    searchBlob: buildSearchBlob({ ...input, name: input.name?.trim() ?? '', diagnoses }),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    updatedBy: getDeviceId(),
    deletedAt: null,
  };

  // Only written when true. `temporary: false` on every patient would be a
  // field that means nothing on the 95% and has to be filtered around forever.
  if (input.temporary) record['temporary'] = true;

  // Firestore rejects `undefined`; omit rather than write nulls that would
  // then have to be distinguished from "explicitly cleared" later.
  for (const key of ['mrn', 'age', 'sex', 'ward', 'bed', 'dpjp'] as const) {
    const value = input[key];
    if (value !== undefined && value !== '') record[key] = value;
  }

  return { id, written: trackWrite(setDoc(patientDoc(id), record)) };
}

/**
 * How much of the note the board caches.
 *
 * Raised from 240 on 2026-09-12. 240 characters was sized for a fixed card
 * showing four lines — the truncation was applied at WRITE time, where the
 * card's size is unknowable, and the `…` was baked into the stored string. So
 * a card the user had dragged twice as tall still ended at
 * "- Hypertensive Heart Di…", because the missing text had never been saved.
 *
 * Cutting belongs at render time, where the box knows its own height. This
 * limit exists now only to stop a pathological note from bloating the patient
 * document, and is set well past any real assessment block.
 */
const PREVIEW_LIMIT = 1600;

/**
 * What the card shows: the assessment, falling back to the note's opening.
 *
 * It used to show whatever came first after the greeting — which is S, so every
 * card read "nyeri dada tidak ada, sesak tidak ada". True, identical across
 * half the ward, and no help at all in finding a patient.
 *
 * The assessment is what identifies them: `CAD 3VD`, `Severe MR pro MVR`,
 * `CHF NYHA IV`. That is the line you scan a board for, so that is the line the
 * card leads with.
 *
 * When there is no assessment yet — a fresh admission, a note still being
 * written — it falls back to the old behaviour rather than showing an empty
 * card, because "nothing written yet" is better said by showing the beginning
 * of what was.
 */
export function buildPreview(body: string, aliases?: readonly SectionAlias[]): string {
  const resolved = aliases ?? DEFAULT_SECTION_ALIASES;
  const sections = parseSections(body, resolved);

  const assessment = sections.find((section) => {
    if (section.sectionId === 'a') return true;
    const haystack = `${section.sectionId} ${section.label}`.toLowerCase();
    return /diagnos|assess|problem/.test(haystack);
  });

  /*
    A consult reply's assessment is its cardiology conclusion, a heading whose
    LINE is the content (`carriesContent`). Its `text` is whatever follows the
    line — usually nothing before the TS blocks — so reading `text` alone
    found an empty assessment and fell back to the note's opening: S, O and
    every investigation, which is what these cards showed.
  */
  const source =
    assessment?.carriesContent && assessment.headerLine
      ? konsulPreview(body, assessment.headerLine, assessment.text)
      : assessment?.text.trim()
        ? assessment.text.trim()
        : body.slice(clinicalStart(sections)).trim();

  return source.length > PREVIEW_LIMIT ? `${source.slice(0, PREVIEW_LIMIT)}…` : source;
}

/**
 * Refreshes the board caches after a body write. Called from entries.repo so
 * no call site can forget it and leave the board showing yesterday's text.
 */
/**
 * Facts the note can tell us about the patient.
 *
 * ABSENCE IS NOT A CORRECTION. An earlier version cleared `dpjpId` whenever the
 * body being written named nobody — which meant opening a fresh day and typing
 * one character wiped the consultant, because a blank new day names nobody.
 * The patient's DPJP is a fact about the patient, not about today's page.
 *
 * So a derived field is only ever WRITTEN when the note actually contains it.
 * Clearing happens when the user clears the field in the identity form, which
 * is the one place they can say they meant it.
 *
 * Identity fields go further and fill only what is BLANK: someone who typed a
 * name into the form outranks a line in a note, and silently overwriting a
 * corrected MRN with the uncorrected one from the note text would be the worst
 * possible reading of "keep them in sync".
 */
function derivedPatientFields(body: string): DocumentData {
  const fields: DocumentData = {};

  const dpjp = primaryDpjp(body);
  if (dpjp) fields['dpjpId'] = dpjp.id;

  // Joint-care role. Derived HERE because this is the only place with the
  // whole body — the board has the preview, which is the diagnosis block on
  // almost every patient and never contains the DPJP lines this depends on.
  const kjs = kjsRole(body);
  if (kjs) fields['kjs'] = kjs;

  return fields;
}

/**
 * Fills blank patient fields from the note. Never overwrites a typed value.
 *
 * Separate from `touchEntryMeta` because it needs the CURRENT patient to know
 * what is blank, and because it should run on a real edit rather than on every
 * autosave flush.
 */
export function fillPatientFromNote(patient: Patient, body: string): Promise<void> | null {
  const facts = parsePatientFacts(body);
  const patch: PatientPatch = {};

  if (!patient.name?.trim() && facts.name) patch.name = facts.name;
  if (!patient.mrn?.trim() && facts.mrn) patch.mrn = facts.mrn;
  if (patient.age === undefined && facts.age !== undefined) patch.age = facts.age;
  if (!patient.sex && facts.sex) patch.sex = facts.sex;
  if (!patient.ward?.trim() && facts.ward) patch.ward = facts.ward;
  if (!patient.room?.trim() && facts.room) patch.room = facts.room;
  if (!patient.bed?.trim() && facts.bed) patch.bed = facts.bed;

  if (Object.keys(patch).length === 0) return null;

  // The search blob is rebuilt from the merged result, so a name learned from
  // the note becomes searchable in the same write that stores it.
  // The search blob is rebuilt from the merged result, so a name learned from
  // the note becomes searchable in the same write that stores it. Optional keys
  // are only included when set — `exactOptionalPropertyTypes` treats "absent"
  // and "present but undefined" as different, and so does Firestore.
  const blobSource: Parameters<typeof buildSearchBlob>[0] = {
    name: patch.name ?? patient.name ?? '',
    diagnoses: patient.diagnoses,
  };
  const mrn = patch.mrn ?? patient.mrn;
  const ward = patch.ward ?? patient.ward;
  const bed = patch.bed ?? patient.bed;
  if (mrn) blobSource.mrn = mrn;
  if (ward) blobSource.ward = ward;
  if (bed) blobSource.bed = bed;
  if (patient.dpjp) blobSource.dpjp = patient.dpjp;

  return updatePatient(patient.id, patch, blobSource);
}

/**
 * Does a write to `date` move the card's preview?
 *
 * Only forward. The card answers "how is this patient TODAY"; opening
 * yesterday to fix a typo used to make the card show yesterday's assessment
 * (and `lastEntryDate` step back), until today's note was typed into again.
 * That stale card is what "Perbarui kartu pasien" was being run to fix.
 */
export function previewMovesTo(stored: ClinicalDate | undefined, date: ClinicalDate): boolean {
  if (isIgdEntry(date)) return false;
  return !stored || date >= stored;
}

export async function touchEntryMeta(
  patientId: string,
  date: ClinicalDate,
  body: string,
): Promise<void> {
  /**
   * The admission note never becomes the card preview.
   *
   * The board answers "where is this patient today", and a card showing the
   * IGD note answers "where were they when they arrived" — which on day six is
   * actively misleading. Writing it still updates the derived fields, because
   * the DPJP and identity in it are as true as anywhere else.
   *
   * The stored preview date is read from the LOCAL cache: instant, works
   * offline, and the board is already subscribed to this document so it is
   * there. When it is not, the write goes ahead as before.
   */
  let stored: ClinicalDate | undefined;
  try {
    const cached = await getDocFromCache(patientDoc(patientId));
    stored = (cached.data() as Patient | undefined)?.previewDate;
  } catch {
    stored = undefined;
  }
  const previewFields: DocumentData = previewMovesTo(stored, date)
    ? { lastEntryDate: date, preview: buildPreview(body), previewDate: date }
    : {};

  return trackWrite(
    updateDoc(patientDoc(patientId), {
      ...previewFields,
      ...derivedPatientFields(body),
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

/**
 * Put `body` (the note of `date`) on the card, when it is not there already.
 *
 * Called when a patient's LATEST day is opened, so any card that drifted —
 * a rule change, a write that raced, a day deleted — heals by being looked
 * at, with no maintenance button. No write when the card is already right.
 */
export function healCardPreview(patient: Patient, date: ClinicalDate, body: string): Promise<void> | null {
  if (!body.trim() || isIgdEntry(date)) return null;
  const preview = buildPreview(body);
  if (patient.preview === preview && patient.previewDate === date) return null;
  return trackWrite(
    updateDoc(patientDoc(patient.id), {
      lastEntryDate: date,
      preview,
      previewDate: date,
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

/**
 * Rewrites the whole cache object rather than merging a single key: a merge
 * would leave yesterday's ticks sitting under today's date the first time an
 * item is ticked after midnight.
 */
export function cacheBoardChecklist(
  patientId: string,
  date: ClinicalDate,
  done: Record<string, boolean>,
): Promise<void> {
  return trackWrite(
    updateDoc(patientDoc(patientId), {
      boardChecklist: { date, done },
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

/**
 * `undefined` is meaningful here, not merely absent: `updatePatient` reads it
 * as "clear this field" and writes `deleteField()`. Under
 * `exactOptionalPropertyTypes` that has to be spelled out, or callers cannot
 * express a clear at all.
 */
export type PatientPatch = {
  [K in PatientPatchKey]?: Patient[K] | undefined;
};

type PatientPatchKey = keyof Pick<
  Patient,
  | 'name'
  | 'mrn'
  | 'age'
  | 'sex'
  | 'ward'
  | 'room'
  | 'bed'
  | 'dpjp'
  | 'dpjpId'
  | 'kjs'
  | 'notes'
  | 'diagnoses'
  | 'labels'
  | 'pinned'
  | 'pemantauan'
  | 'ekgHarian'
  | 'ekgFor'
  | 'temporary'
  | 'chief'
  | 'discharge'
  | 'dischargePlannedFor'
  | 'todos'
  | 'colorOverride'
  | 'admittedAt'
  | 'lastEntryDate'
>;

/**
 * Write one day's checklist ticks.
 *
 * A field PATH, not a `todoTicks` object in a patch. `updateDoc` replaces a
 * top-level field wholesale, so sending the whole map would let a device that
 * had not yet seen yesterday's write erase it. Addressing the single date
 * leaves every other day untouched by the server.
 *
 * `FieldPath` rather than the dotted string form because a clinical date starts
 * with a digit and contains hyphens, which the string form requires to be
 * backtick-escaped — a rule that is easy to get right once and easy to forget
 * the next time somebody edits this line.
 */
export function setTodoTicks(
  patientId: string,
  date: ClinicalDate,
  ids: readonly string[],
): Promise<void> {
  return trackWrite(
    updateDoc(
      patientDoc(patientId),
      new FieldPath('todoTicks', date),
      [...ids],
      'updatedAt',
      serverTimestamp(),
      'updatedBy',
      getDeviceId(),
    ),
  );
}

export function updatePatient(
  patientId: string,
  patch: PatientPatch,
  searchBlobSource?: Parameters<typeof buildSearchBlob>[0],
): Promise<void> {
  const payload: DocumentData = {
    ...patch,
    updatedAt: serverTimestamp(),
    updatedBy: getDeviceId(),
  };
  if (searchBlobSource) payload['searchBlob'] = buildSearchBlob(searchBlobSource);

  // An explicit `undefined` in a patch means "clear this field".
  for (const [key, value] of Object.entries(patch)) {
    if (value === undefined) payload[key] = deleteField();
  }

  return trackWrite(updateDoc(patientDoc(patientId), payload));
}

/**
 * Set one daily reminder on a patient: one leaf, `reminders.<kind>`, so two
 * reminders set in quick succession (or from two devices) never overwrite
 * each other. Setting the EKG kind also clears the legacy `ekgHarian` /
 * `ekgFor`, which would otherwise keep the old badge alive underneath.
 */
export function setPatientReminder(
  patientId: string,
  kindId: string,
  setting: ReminderSetting,
): Promise<void> {
  const legacy: unknown[] =
    kindId === 'ekg' ? [new FieldPath('ekgHarian'), deleteField(), new FieldPath('ekgFor'), deleteField()] : [];
  return trackWrite(
    updateDoc(
      patientDoc(patientId),
      new FieldPath('reminders', kindId),
      setting,
      ...legacy,
      new FieldPath('updatedAt'),
      serverTimestamp(),
      new FieldPath('updatedBy'),
      getDeviceId(),
    ),
  );
}

/** Today's reminder ticks, written whole (a small list for one day). */
export function setReminderDone(
  patientId: string,
  done: { date: ClinicalDate; ids: string[] },
): Promise<void> {
  return trackWrite(
    updateDoc(patientDoc(patientId), {
      reminderDone: done,
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

/**
 * Edit the note on an already-archived patient.
 *
 * The reason and the timestamp stay fixed — they record what happened and when,
 * and a record you can rewrite is not a record. The note is the one part that
 * is commentary rather than fact, so it is the one part that can be corrected.
 */
export function updateArchiveNote(patientId: string, note: string): Promise<void> {
  return trackWrite(
    updateDoc(patientDoc(patientId), {
      'archive.note': note.trim(),
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

export function archivePatient(
  patientId: string,
  reason: ArchiveReason,
  note?: string,
): Promise<void> {
  const archive: DocumentData = { reason, at: serverTimestamp() };
  if (note && note.trim()) archive['note'] = note.trim();

  return trackWrite(
    updateDoc(patientDoc(patientId), {
      status: 'archived' satisfies PatientStatus,
      archive,
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

export function reopenPatient(patientId: string): Promise<void> {
  return trackWrite(
    updateDoc(patientDoc(patientId), {
      status: 'active' satisfies PatientStatus,
      archive: deleteField(),
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

/**
 * Soft delete.
 *
 * Sets `deletedAt`, which every query already filters on, so the patient
 * disappears from the board and the archive at once. The document itself
 * stays: `firestore.rules` still denies hard `delete`, so a mistake here is
 * recoverable by an admin rather than final. Restoring is a one-field write.
 */
export function deletePatient(patientId: string): Promise<void> {
  return trackWrite(
    updateDoc(patientDoc(patientId), {
      deletedAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

/**
 * SPEC 1.2 rule 5 — the blank page.
 *
 * Tapping + on the board creates the record immediately and navigates. No
 * sheet, no required fields, nothing between the tap and a cursor in an empty
 * note. Identity can be filled in later, or never: the board derives a title
 * from the note itself.
 *
 * `admittedAt` defaults to today because hari rawat has to count from
 * something; it is editable afterwards like every other field.
 */
export function createBlankPatient(
  uid: string,
  today: ClinicalDate,
  /**
   * Which list the patient lands in.
   *
   * Passed rather than assumed, because the caller knows which list the user
   * was looking at when they pressed the button and this function does not.
   * Defaulting to `false` keeps every existing call creating an ordinary
   * patient, which is what they meant.
   */
  temporary = false,
): { id: string; written: Promise<void> } {
  return createPatient(uid, temporary ? { admittedAt: today, temporary: true } : { admittedAt: today });
}

/**
 * There is NO delete in this repository — not even a soft one.
 *
 * Removing a patient from the board is archiving, and archiving keeps every
 * entry, checklist day and revision. A delete path would exist only to satisfy
 * a tidiness instinct, and the cost of a mis-tap is a ward round's worth of
 * notes. `deletedAt` survives in the schema because every query filters on it
 * and the security rules already deny `delete` outright.
 */

/** v1 no-op seam: sharing is a config change, not a migration (SPEC 6.1). */
export function addMember(patientId: string, uid: string): Promise<void> {
  return trackWrite(
    updateDoc(patientDoc(patientId), {
      memberIds: arrayUnion(uid),
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}

export function subscribePatient(
  patientId: string,
  callback: (patient: Patient | null) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  return onSnapshot(
    patientDoc(patientId),
    (snapshot) => callback(snapshot.exists() ? (snapshot.data() as Patient) : null),
    onError,
  );
}

export interface PatientsSnapshot {
  patients: Patient[];
  /** True while the payload is served from cache with writes still queued. */
  fromCache: boolean;
  hasPendingWrites: boolean;
}

function mapSnapshot(snapshot: QuerySnapshot): PatientsSnapshot {
  return {
    patients: snapshot.docs.map((entry) => entry.data() as Patient),
    fromCache: snapshot.metadata.fromCache,
    hasPendingWrites: snapshot.metadata.hasPendingWrites,
  };
}

/**
 * Board query (SPEC 8): memberIds array-contains uid, status, deletedAt,
 * ordered pinned desc then updatedAt desc. Mirrored in firestore.indexes.json.
 */
export function subscribePatients(
  uid: string,
  status: PatientStatus,
  callback: (snapshot: PatientsSnapshot) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  const q = query(
    patientsCol(),
    where('memberIds', 'array-contains', uid),
    where('status', '==', status),
    where('deletedAt', '==', null),
    // Newest note first, like a notes app. The previous pinned+updatedAt
    // ordering reshuffled the board every time anyone typed a character,
    // so a card was never twice in the same place — unusable on a round.
    orderBy('createdAt', 'desc'),
  );

  return onSnapshot(
    q,
    // Cache-first so the board paints with no signal, then re-renders on sync.
    { includeMetadataChanges: true },
    (snapshot) => callback(mapSnapshot(snapshot)),
    onError,
  );
}


/**
 * Destroy a patient and everything under it, permanently.
 *
 * Firestore does NOT cascade. Deleting the patient document alone leaves its
 * entries, their revisions and its checklists in place — still stored, still
 * billed, and now unreadable, because the rules for those subcollections check
 * membership by reading the PARENT document that no longer exists. Orphaned
 * data you cannot see and cannot delete is the worst of both outcomes, so the
 * order here is deepest-first and the patient goes last.
 *
 * Batched at 400 rather than Firestore's 500 limit, leaving room for the
 * writes an open listener may add while this runs.
 *
 * Not resumable. A purge interrupted halfway leaves a patient whose notes are
 * partly gone, which is why the caller confirms with a count first and why
 * this is only ever reached from an explicit "empty trash".
 */
export async function purgePatient(patientId: string): Promise<void> {
  const BATCH = 400;

  const flush = async (refs: DocumentReference[]): Promise<void> => {
    for (let i = 0; i < refs.length; i += BATCH) {
      const batch = writeBatch(db());
      for (const ref of refs.slice(i, i + BATCH)) batch.delete(ref);
      await batch.commit();
    }
  };

  const entries = await getDocs(entriesCol(patientId));

  // Revisions first: they are the deepest, and each entry may have dozens.
  for (const entry of entries.docs) {
    const revisions = await getDocs(revisionsCol(patientId, entry.id));
    await flush(revisions.docs.map((doc) => doc.ref));
  }

  await flush(entries.docs.map((doc) => doc.ref));

  const checklists = await getDocs(checklistCol(patientId));
  await flush(checklists.docs.map((doc) => doc.ref));

  // The patient itself last. Until this line the rules still resolve, so an
  // interrupted purge leaves something that can be retried.
  await trackWrite(deleteDoc(patientDoc(patientId)));
}

/** Move patients to the trash, or back out of it. */
export function setPatientStatus(
  patientId: string,
  status: PatientStatus,
): Promise<void> {
  return trackWrite(
    updateDoc(patientDoc(patientId), {
      status,
      updatedAt: serverTimestamp(),
      updatedBy: getDeviceId(),
    }),
  );
}
